var changeGraphType = {
    widget: null,
    leftMenuState: true,

    funcInit: function (widget) {
        this.widget = widget;
    },

    funcChangeType: function(type) {
        this.widget.chart().setChartType(parseInt(type));
    },

    funcChangeTimeframe: function(timeframe) {
        this.widget.chart().setResolution(timeframe);
    },

    funcCreateStudy: function(study) {
        if (Array.isArray(study)) {
            for (var i = 0; i < study.length; i++) {
                this.widget.chart().createStudy(study[i], false, false, null);
            }
        } else {
            this.widget.chart().createStudy(study, false, false, null);
        }
    },

    funcOpenChartProperties: function() {
        this.widget.chart().executeActionById('chartProperties');
    },

    funcUndo: function () {
        this.widget.chart().executeActionById('undo');
    },

    funcRedo: function () {
        this.widget.chart().executeActionById('redo');
    },

    funcShowObjectTree: function () {
        this.widget.chart().executeActionById('paneObjectTree');
    },

    funcSaveIndicators: function (callbackFunction) {
        var studys = this.widget.chart().getAllStudies(), studyObjects = {};
        for (var i = 0; i < Object.keys(studys).length; i++) {
            var study = this.widget.chart().getStudyById(studys[i]['id'])
            studyObjects[studys[i]['id']] = {study_name: studys[i]['name'], study_input: study.getInputValues()}
        }
        console.log(studys);
        function callbackFunction() {
            return studyObjects;
        }

        return callbackFunction();
    },

    funcLoadIndicators: function (studyObjects) {
        if (typeof studyObjects === 'undefined' || studyObjects === null) return;
        for (var i = 0; i < Object.keys(studyObjects).length; i++) {
            currentStudy =  studyObjects[Object.keys(studyObjects)[i]];
            if (currentStudy['study_input'].length === 0) {
                this.widget.chart().createStudy(currentStudy['study_name'], false, false, null);
            } else {
                var inp_values = [];
                for (var j = 0; j < currentStudy['study_input'].length; j++) {
                    inp_values.push(currentStudy['study_input'][j]['value']);
                }
                this.widget.chart().createStudy(currentStudy['study_name'], false, false, inp_values);
            }
        }
    },

    funcSaveObject: function (callbackFunction) {
        var drawObjects = this.widget.chart().getAllShapes(), drawingObjects = {};
        for (var i = 0; i < Object.keys(drawObjects).length; i++) {
            var object = this.widget.chart().getShapeById(drawObjects[i]['id'])
            drawingObjects[drawObjects[i]['id']] = {object_name: drawObjects[i]['name'], object_points: object.getPoints(), object_text: ('text' in object.getProperties() ? object.getProperties()['text'] : '')};
        }
        
        function callbackFunction() {
            return drawingObjects;
        }

        return callbackFunction();
    },

    funcLoadObject: function (drawingObjects) {
        if (typeof drawingObjects === 'undefined' || drawingObjects === null) return;
        for (var i = 0; i < Object.keys(drawingObjects).length; i++) {
            var selectedObject = drawingObjects[Object.keys(drawingObjects)[i]];
            if (selectedObject['object_points'].length === 1) {          
                this.widget.chart().createShape(
                    {time: selectedObject['object_points'][0]['time'], price: selectedObject['object_points'][0]['price']}, 
                    {shape: selectedObject['object_name'], text: selectedObject['object_text']}
                );
            } else {
                var pointsArr = [];
                for (var j = 0; j < selectedObject['object_points'].length; j++) {
                    var point_value = selectedObject['object_points'][j];
                    pointsArr.push({time: point_value['time'], price: point_value['price']});
                }
                this.widget.chart().createMultipointShape(pointsArr, {shape: selectedObject['object_name'], text: selectedObject['object_text']});
            }
        }
    }, 

    funcGetTicks: function (callbackFunction, delay) {
        var frame = document.getElementById(this.widget._id);
		var tmptickElement = frame.contentDocument.getElementsByClassName('onlyOneButtonCanBeStick-2KhwsEwE');
		var tickElement = null;
		var finalObject = {};

		for (var i = 0; i < tmptickElement.length; i++) {
			if (typeof tmptickElement[i].dataset !== 'undefined') {
				if (tmptickElement[i].dataset.name === 'legend-series-item') {
					tickElement = tmptickElement[i].lastElementChild.firstElementChild;
				}
			}
		}

		tickElement = tickElement.children;
        
		setTimeout(function() {
				for (var i = 0; i < tickElement.length - 1; i++) {
					if (tickElement[i].firstElementChild.innerHTML !== '') {
						switch(tickElement[i].firstElementChild.innerHTML) {
							case 'O':
								finalObject['open'] = tickElement[i].lastElementChild.innerHTML;
							case 'H':
								finalObject['high'] = tickElement[i].lastElementChild.innerHTML;
							case 'L':
								finalObject['low'] = tickElement[i].lastElementChild.innerHTML;
							case 'C':
								finalObject['close'] = tickElement[i].lastElementChild.innerHTML;
						}
					}
				}

				finalObject['change'] = tickElement[tickElement.length - 1].lastElementChild.innerHTML;
				finalObject['color'] = tickElement[tickElement.length - 1].lastElementChild.style.color;
                function callbackFunction() {
                    console.log(finalObject)
                    return finalObject;
                }
        
                return callbackFunction();
		}.bind(callbackFunction), delay*1000)
    },

    funcClearAllObjects: function () {
        this.widget.chart().removeAllShapes();
    },

    funcShowHideToolbar: function (callbackFunction) {
        this.widget.chart().executeActionById("drawingToolbarAction");
        this.funcCheckToolbarStatus(callbackFunction);
    },

    funcChangeToolbarStatus: function (state) {
        this.leftMenuState = state;
    },

    funcCheckToolbarStatus: function (callbackFunction) {
        state = this.leftMenuState;
        console.log(state);
        function callbackFunction() {
            return state;
        }

        return callbackFunction();
    },

    funcClearAllIndicators: function () {
        this.widget.chart().removeAllStudies();
    },

    funcSetPriceScaleMode: function (mode) {
        var panes = this.widget.chart().getPanes();
        for (var i = 0; i < Object.keys(panes).length; i++) {
            if (panes[i].hasMainSeries()) {
                panes[i].getMainSourcePriceScale().setMode(parseInt(mode));
            }
        }
    },

    funcResetGraph: function () {
        this.widget.chart().executeActionById("chartReset");
    },

    funcRemoveIndicator: function (id) {
        this.widget.chart().removeEntity(id);
    },

    funcGetFrameID: function (callbackFunction) {
        var frame = this.widget._id;
        console.log(frame);
        function callbackFunction() {
            return frame;
        }

        return callbackFunction();
    }
};